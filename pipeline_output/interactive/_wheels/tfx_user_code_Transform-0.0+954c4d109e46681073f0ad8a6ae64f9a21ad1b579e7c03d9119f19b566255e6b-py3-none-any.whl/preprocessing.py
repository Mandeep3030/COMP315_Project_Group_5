import tensorflow as tf
import tensorflow_transform as tft

NUMERIC_FEATURES = [
    "age",
    "balance",
    "day",
    "duration",
    "campaign",
    "pdays",
    "previous",
]

CATEGORICAL_FEATURES = [
    "job",
    "marital",
    "education",
    "default",
    "housing",
    "loan",
    "contact",
    "month",
    "poutcome",
]

LABEL_KEY = "y"


def transformed_name(key):
    return key + "_xf"


def preprocessing_fn(inputs):
    outputs = {}

    # Scale numerical features using z-score normalization.
    for key in NUMERIC_FEATURES:
        outputs[transformed_name(key)] = tft.scale_to_z_score(
            inputs[key]
        )

    # Convert categorical strings to integer vocabulary IDs.
    for key in CATEGORICAL_FEATURES:
        outputs[transformed_name(key)] = (
            tft.compute_and_apply_vocabulary(inputs[key])
        )

    # Convert target "no"/"yes" to 0/1.
    outputs[transformed_name(LABEL_KEY)] = tf.cast(
        tf.equal(inputs[LABEL_KEY], "yes"),
        tf.int64
    )

    return outputs
